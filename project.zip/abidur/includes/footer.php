<footer class="main-footer">
    <div class="container">
      <div class="pull-right hidden-xs">
        <b>All rights reserved</b>
      </div>
      <strong>Copyright &copy; 2019 Brought to You By <a href="https://code-projects.org/">Abidur Rahman</a></strong>
    </div>
</footer>